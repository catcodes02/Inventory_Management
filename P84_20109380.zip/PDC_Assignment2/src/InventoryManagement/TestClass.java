package InventoryManagement;

public class TestClass {

    public static void main(String[] args) {
        InventoryManagementController test = new InventoryManagementController();
        test.startProgram();
    }
}

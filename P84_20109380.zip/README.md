# Inventory_Management

#### AUT COMP603 Assignment 2

Run the project on NetBeans through the "TestClass" class under the InventoryManagement package.

**SETUP:**\
When opening the project in NetBeans it may ask you to "Resolve Project Problems".

-   Click "Resolve Problems..."

-   With "derby.jar" selected, click "Resolve..."

    -   Find your way through your files to the location in the project folder as shown:\
        ' *FolderLocation* \\P84_20109380\\PDC_Assignment2\\dist\\lib '

    -   Select the derby.jar file and hit "Open"

-   Repeat the above step with "derbyclient.jar"

-   NetBeans should now say "This problem was resolved" under 'Description:'

-   Close the 'Resolve Project Problems' window and the project is ready to run.

**!!! This issue was discussed with the lecturer (Weihua Li), and he said that it was okay and that it won't count as part of the "The program is easy to compile and run without any manual configurations (e.g., setup DB, import .jar, etc.)" criteria. !!!**
